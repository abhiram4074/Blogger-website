# How to Create a Blog PHP & MySQL database

## PHP Blogging Website


version: 1.0.0

## TECHNOLOGIES

1. PHP
1. HTML & CSS
1. JQuery AJAX
1. Javascript
1. Bootstrap 5



## Full Tutorial

[On Youtube](https://www.youtube.com/playlist?list=PL2WFgdVk-usFBEBfk6TVrlHyyaFg0Z1Kg)

## Authors

[Elias Abdurrahman](https://github.com/codingWithElias)